/* eslint-disable no-console */

const CURRENT_VERSION = '5.7.1';

// 导出当前版本号供其他地方使用
export { CURRENT_VERSION };
